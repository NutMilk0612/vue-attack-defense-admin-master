<template>
    <div id="video">
    <iframe
         ref="iframe"
         :src="htmlSrc"
         frameborder="0"
         style="width:1440px; height:960px; border: 0;display:block"
     />
    </div>

</template>

<script>
    export default {
      data() {
        return {
          htmlSrc: 'face-api.html'  //该页面在public文件夹下
        }
      }
    }
</script>

<style>
#video 
{
    background-size:cover;  /*框自动居中 */
    position:absolute;
    width:1440px;
    height:960px;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    border-radius5: 10px;
  }
</style>
